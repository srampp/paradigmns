# Breath hold
This paradimn was created with PsychoPy 3 (https://www.psychopy.org/index.html). It implements a breath hold fMRI paradigm according to the recommendations of the ASFNR (https://www.asfnr.org/). Specifications, durations and scanner parameters are found here: http://www.ajnr.org/content/38/10/E65.
